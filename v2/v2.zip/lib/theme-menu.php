<?php
/**
 * Register the Main Menu required for any theme,
 * Should be above the Dashboard
 *
 * @package     GloriousDashboard
 * @author      Glorious Motive
 * @copyright   2021
 * @license     GPL-2.0+
 */

if( ! function_exists ( 'gloriousmotive_register_mainmenu' ) ) {
    function gloriousmotive_register_mainmenu() {
        return "Hello";
        print 'true';
    }   
}


/**
 * Register the Admin Menu above Dashboard
 * 
 *  @since 1.0.0
 */

function gloriousmotive_admin_menu(){
	global $gloriousmotive_admin_screens;

	$admin_menu_page = array (
		'title' => esc_html__('GloriousMotive','glorious-framework'),
		'menu_title' => esc_html__('GloriousMotive','glorious-framework'),
		'capability' => 'edit_theme_options',
		'menu_slug' => 'glorious',
		'function' => 'gloriousdash_dashboard_page',//'gloriousmotive_admin_page_welcome',
		'icon_url' => GLORIOUS_MOTIVE_PLUGIN_URL . 'assets/img/icon-trp.png',
		'position' => '0',
	);
	$menu_page = apply_filters( 'gloriousmotive_admin_menu_page', $admin_menu_page );


	if ( current_user_can( 'edit_theme_options' ) ) {
		
		add_menu_page( 
			$menu_page['title'], 
			$menu_page['menu_title'], 
			$menu_page['capability'], 
			$menu_page['menu_slug'], 
			$menu_page['function'], 
			$menu_page['icon_url'],  
			$menu_page['position'] 
		);

      if( empty ( $gloriousmotive_admin_screens ) ) {
         
         // Create this Menu when no Glorious Products are active
         add_submenu_page( 
            'glorious', 
            'GloriousMotive - Add Product', 
            '- List of Products', 
            'edit_theme_options', 
            'no-glorious-products', 
            'gloriousmotive_no_products_page' 
         );
         
      } else {
         /**
          * Loop through the admin screens
          * and add them to the menu
          *
          * Gets the data from the theme
          * 
          * @since 1.0.0
          */
         foreach ( $gloriousmotive_admin_screens as $screen ) {
            add_submenu_page( 
               'glorious', 
               $screen['title'], 
               '- '.$screen['title'], 
               'edit_theme_options', 
               $screen['id'], 
               $screen['function'] 
            );
         }
      }
		
		
	}
}
add_action( 'admin_menu', 'gloriousmotive_admin_menu' );



/**
 * Adds additional menu for menu-slug
 * 
 * Loads with class in the main file
 *
 * @return void
 */
if( ! function_exists( 'gloriousdash_dashboard_register_additional_menu' ) ) {

    function gloriousdash_dashboard_register_additional_menu() {
        
      //Glorious Products
      //add_submenu_page( 'glorious', 'Gloriousdash Products', '- Products', 'manage_options', 'gloriousdash-dashboard-products', 'gloriousdash_dashboard_products' );

      // submenu for list of products
      add_submenu_page( '', 'Gloriousdash Licenses', '- Licenses', 'manage_options', 'glorious-licenses', 'glorious_themes_license_page' );

      //Install Plugins Page
      add_submenu_page( '', 'Gloriousdash Install Plugins', '- Install Plugins', 'manage_options', 'glorious-install-plugins', 'glorious_install_plugins_page' );

      //Demo import is added via OneClickDemoImport Plugin

      //Theme Settings
      add_submenu_page( '', 'Glorious Setup', '- Setup Up', 'manage_options', 'glorious-setup', 'glorious_setups' );

      //Glorious Plugins
      add_submenu_page( '', 'Glorious Plugins', 'Glorious Plugins', 'read', 'glorious-plugins', 'glorious_plugins_page' );

      //Glorious Services
      add_submenu_page( '', 'Glorious Services', 'Glorious Services', 'read', 'glorious-services', 'glorious_services_page' );

      //Glorious Themes
      add_submenu_page( '', 'Glorious Themes', 'Glorious Themes', 'read', 'glorious-themes', 'glorious_gloriousthemes_page' );

      //Glorious ThemeForest
      add_submenu_page( '', 'ThemeForest', 'Glorious ThemeForest', 'read', 'glorious-themeforest', 'glorious_themeforest_page' );

      //Glorious Plugins
      add_submenu_page( '', 'CodeCanyon', 'Glorious CodeCanyon', 'read', 'glorious-codecanyon', 'glorious_codecanyon_page' );

      // System Status for Theme, WP and Server
      add_submenu_page( '', 'Gloriousdash System Status', '- System Status', 'manage_options', 'glorious-system-status', 'glorious_system_status_page' );

      // System Status for support team
      add_submenu_page( '', 'Gloriousdash System Help', '- System Help Team', 'manage_options', 'glorious-support-system-status', 'glorious_support_system_status_page' );

      
        
    }

}
// Theme Dashboard
if ( ! function_exists ( 'gloriousdash_dashboard_page' ) ) {
   function gloriousdash_dashboard_page() {
      require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/glorious_dashboard.php';
   }
}

// License Integration
if ( ! function_exists ( 'glorious_themes_license_page' ) ) {
   function glorious_themes_license_page() {
      require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'lib/api/updater/integrate-theme-license.php';
   }
}

// License Integration
if ( ! function_exists ( 'glorious_install_plugins_page' ) ) {
   function glorious_install_plugins_page() {
      require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/glorious-install-plugins.php';
   }
}

//All Glorious Products
if ( ! function_exists( 'glorious_plugins_page' ) ) {
   function glorious_plugins_page() {
       require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/pages/glorious-plugins.php'; 
   }
}

//All Glorious Services
if ( ! function_exists( 'glorious_services_page' ) ) {
   function glorious_services_page() {
       require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/pages/glorious-services.php'; 
   }
}

//All Glorious Themes
if ( ! function_exists( 'glorious_gloriousthemes_page' ) ) {
   function glorious_gloriousthemes_page() {
       require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/pages/glorious-gloriousthemes.php'; 
   }
}

//Themeforest Products
if ( ! function_exists( 'glorious_themeforest_page' ) ) {
   function glorious_themeforest_page() {
       require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/pages/glorious-themeforest.php'; 
   }
}

//Codecanyon page
if ( ! function_exists( 'glorious_codecanyon_page' ) ) {
   function glorious_codecanyon_page() {
       require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/pages/glorious-codecanyon.php'; 
   }
}

// Runs when No Products are found from Glorious Motive
if ( ! function_exists( 'gloriousmotive_no_products_page' ) ) {
    function gloriousmotive_no_products_page() {
        require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/glorious-no-products.php'; //Register Styles
    }
}

//System Status
if ( ! function_exists( 'glorious_system_status_page' ) ) {
   function glorious_system_status_page() {
       require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/pages/glorious-system-status.php'; //Register Styles
   }
}

//This function is just for No errors to be displayed in the admin area. The main function is called by Redux framework for theme settings
//@since 1.0.0
function glorious_setups() {}