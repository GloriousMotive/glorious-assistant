<?php
/**
 * Fetch themeforest from github for latest display
 * 
 * @since 1.0.0
**/
if ( ! function_exists( 'glorious_themeforest' ) ) {
   function glorious_themeforest( ) {
      //Remove for sercurity Purpose as it violates WP Repo policy
      //$url = 'https://raw.githubusercontent.com/GloriousThemes/glorious-fetch-products/main/glorious/themeforest.json';

      $url = GLORIOUS_MOTIVE_PLUGIN_URL . '/lib/json/themeforest.json';

      //sanintize the url
      $url = esc_url( $url );

      $glorious_themeforest_request = wp_remote_get( $url );

      if( is_wp_error( $glorious_themeforest_request ) ) {
         return false; // bail now
      }

      // retrieve the bodu of the JSON file
      $glorious_themeforest_body = wp_remote_retrieve_body( $glorious_themeforest_request );

      //Decode the body of the JSON Files
      $glorious_themeforest_data = json_decode( $glorious_themeforest_body );
      //$decode = json_decode( file_get_contents( $url ), true );

      //var_dump($glorious_themeforest_body);

      if( ! empty ( $glorious_themeforest_data ) ) {
         foreach ( $glorious_themeforest_data->products as $glorious_themeforest ) {
            //This things are being fetched
            //echo $glorious_themeforest->title . "<br>";
            //echo $glorious_themeforest->desc . "<br>";
            //echo $glorious_themeforest->icon . "<br>";
            //echo $glorious_themeforest->buylink . "<br>";
            //echo $glorious_themeforest->settingslink . "<br>";?>


               <li data-v-0577a48d="">
                  <div data-v-0577a48d="" class="plugin-picture"
                     style="background-image: url(&quot;<?php echo esc_html_e( GLORIOUS_MOTIVE_PLUGIN_URL . $glorious_themeforest->icon, 'gloriousmotive' ); ?>&quot;);">
                  </div>
                  <div data-v-0577a48d="" class="gloriousui-plugin-info"><span data-v-0577a48d=""><span data-v-0577a48d=""
                           class="gloriousui-white-text"><?php echo esc_html_e( $glorious_themeforest->title
                           , 'gloriousmotive' ) ;?> - <?php echo esc_html_e( $glorious_themeforest->title2, 'gloriousmotive' );?></span></span>
                     <p data-v-0577a48d=""><?php echo esc_html_e( $glorious_themeforest->desc, 'gloriousmotive' ); ?></p>
                  </div>
                  <a data-v-0577a48d="" target="_blank" href="<?php echo esc_html_e( $glorious_themeforest->buylink, 'gloriousmotive' ); ?>" class="gloriousui-btn">Download Now</a>
               </li>

         <?php
         }
      }

   }
}
?>