<?php
/**
 * Fetch themes from github for latest display
 * 
 * @since 1.0.0
**/
if ( ! function_exists( 'glorious_themes' ) ) {
   function glorious_themes( ) {
      //Remove for sercurity Purpose as it violates WP Repo policy
      //$url = 'https://raw.githubusercontent.com/GloriousThemes/glorious-fetch-products/main/glorious/themes.json';

      $url = GLORIOUS_MOTIVE_PLUGIN_URL . '/lib/json/themes.json';

      //sanintize the url
      $url = esc_url( $url );

      $glorious_themes_request = wp_remote_get( $url );

      if( is_wp_error( $glorious_themes_request ) ) {
         return false; // bail now
      }

      // retrieve the bodu of the JSON file
      $glorious_themes_body = wp_remote_retrieve_body( $glorious_themes_request );

      //Decode the body of the JSON Files
      $glorious_themes_data = json_decode( $glorious_themes_body );
      //$decode = json_decode( file_get_contents( $url ), true );

      //var_dump($glorious_themes_body);

      if( ! empty ( $glorious_themes_data ) ) {
         foreach ( $glorious_themes_data->products as $glorious_themes ) {
            //This things are being fetched
            //echo $glorious_themes->title . "<br>";
            //echo $glorious_themes->desc . "<br>";
            //echo $glorious_themes->icon . "<br>";
            //echo $glorious_themes->buylink . "<br>";
            //echo $glorious_themes->settingslink . "<br>";?>


               <li data-v-0577a48d="">
                  <div data-v-0577a48d="" class="plugin-picture"
                     style="background-image: url(&quot;<?php echo esc_html_e( GLORIOUS_MOTIVE_PLUGIN_URL . $glorious_themes->icon, 'gloriousmotive' ); ?>&quot;);">
                  </div>
                  <div data-v-0577a48d="" class="gloriousui-plugin-info"><span data-v-0577a48d=""><span data-v-0577a48d=""
                           class="gloriousui-white-text"><?php echo esc_html_e( $glorious_themes->title
                            , 'gloriousmotive' ) ;?> - <?php echo esc_html_e( $glorious_themes->title2 , 'gloriousmotive' );?></span></span>
                     <p data-v-0577a48d=""><?php echo esc_html_e( $glorious_themes->desc , 'gloriousmotive' ); ?></p>
                  </div>
                  <a data-v-0577a48d="" target="_blank" href="<?php echo esc_html_e( $glorious_themes->buylink , 'gloriousmotive' ); ?>" class="gloriousui-btn">Know More Details</a>
               </li>

         <?php
         }
      }

   }
}
?>