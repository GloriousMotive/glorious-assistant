<?php
/**
 * Fetch codecanyon from github for latest display
 * 
 * @since 1.0.0
**/
if ( ! function_exists( 'glorious_codecanyon' ) ) {
   function glorious_codecanyon( ) {
      //Remove for sercurity Purpose as it violates WP Repo policy
      //$url = 'https://raw.githubusercontent.com/GloriousThemes/glorious-fetch-products/main/envato/codecanyon.json';
      
      $url = GLORIOUS_MOTIVE_PLUGIN_URL . '/lib/json/codecanyon.json';

      //sanintize the url
      $url = esc_url( $url );

      $glorious_codecanyon_request = wp_remote_get( $url );

      if( is_wp_error( $glorious_codecanyon_request ) ) {
         return false; // bail now
      }

      // retrieve the bodu of the JSON file
      $glorious_codecanyon_body = wp_remote_retrieve_body( $glorious_codecanyon_request );

      //Decode the body of the JSON Files
      $glorious_codecanyon_data = json_decode( $glorious_codecanyon_body );
      //$decode = json_decode( file_get_contents( $url ), true );

      //var_dump($glorious_codecanyon_body);

      if( ! empty ( $glorious_codecanyon_data ) ) {
         foreach ( $glorious_codecanyon_data->products as $glorious_codecanyon ) {
            //This things are being fetched
            //echo $glorious_codecanyon->title . "<br>";
            //echo $glorious_codecanyon->desc . "<br>";
            //echo $glorious_codecanyon->icon . "<br>";
            //echo $glorious_codecanyon->buylink . "<br>";
            //echo $glorious_codecanyon->settingslink . "<br>";?>


               <li data-v-0577a48d="">
                  <div data-v-0577a48d="" class="plugin-picture"
                     style="background-image: url(&quot;<?php echo esc_html_e( GLORIOUS_MOTIVE_PLUGIN_URL . $glorious_codecanyon->icon, 'gloriousmotive' ); ?>&quot;);">
                  </div>
                  <div data-v-0577a48d="" class="gloriousui-plugin-info"><span data-v-0577a48d=""><span data-v-0577a48d=""
                           class="gloriousui-white-text"><?php echo esc_html_e( $glorious_codecanyon->title
                           , 'gloriousmotive' ) ;?> - <?php echo esc_html_e( $glorious_codecanyon->title2, 'gloriousmotive' );?></span></span>
                     <p data-v-0577a48d=""><?php echo esc_html_e( $glorious_codecanyon->desc, 'gloriousmotive' ); ?></p>
                  </div>
                  <a data-v-0577a48d="" target="_blank" href="<?php echo esc_html_e( $glorious_codecanyon->buylink, 'gloriousmotive' ); ?>" class="gloriousui-btn">Download Now</a>
               </li>

         <?php
         }
      }

   }
}
?>