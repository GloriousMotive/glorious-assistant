<?php
/**
 * Fetch plugins from github for latest display
 * 
 * @since 1.0.0
**/
if ( ! function_exists( 'glorious_plugins' ) ) {
   function glorious_plugins( ) {
      //Remove for sercurity Purpose as it violates WP Repo policy
      //$url = 'https://raw.githubusercontent.com/GloriousThemes/glorious-fetch-products/main/glorious/plugins.json';

      $url = GLORIOUS_MOTIVE_PLUGIN_URL . '/lib/json/plugins.json';

      //sanintize the url
      $url = esc_url( $url );

      $glorious_plugins_request = wp_remote_get( $url );

      if( is_wp_error( $glorious_plugins_request ) ) {
         return false; // bail now
      }

      // retrieve the bodu of the JSON file
      $glorious_plugins_body = wp_remote_retrieve_body( $glorious_plugins_request );

      //Decode the body of the JSON Files
      $glorious_plugins_data = json_decode( $glorious_plugins_body );
      //$decode = json_decode( file_get_contents( $url ), true );

      //var_dump($glorious_plugins_body);

      if( ! empty ( $glorious_plugins_data ) ) {
         foreach ( $glorious_plugins_data->products as $glorious_plugins ) {
            //This things are being fetched
            //echo $glorious_plugins->title . "<br>";
            //echo $glorious_plugins->desc . "<br>";
            //echo $glorious_plugins->icon . "<br>";
            //echo $glorious_plugins->buylink . "<br>";
            //echo $glorious_plugins->settingslink . "<br>";?>


               <li data-v-0577a48d="">
                  <div data-v-0577a48d="" class="plugin-picture"
                     style="background-image: url(&quot;<?php echo esc_html_e( GLORIOUS_MOTIVE_PLUGIN_URL . $glorious_plugins->icon, 'gloriousmotive' ); ?>&quot;);">
                  </div>
                  <div data-v-0577a48d="" class="gloriousui-plugin-info"><span data-v-0577a48d=""><span data-v-0577a48d=""
                           class="gloriousui-white-text"><?php echo esc_html_e( $glorious_plugins->title
                           , 'gloriousmotive' ) ;?> - <?php echo esc_html_e( $glorious_plugins->title2, 'gloriousmotive' );?></span></span>
                     <p data-v-0577a48d=""><?php echo esc_html_e( $glorious_plugins->desc, 'gloriousmotive' ); ?></p>
                  </div>
                  <a data-v-0577a48d="" target="_blank" href="<?php echo esc_html_e( $glorious_plugins->buylink, 'gloriousmotive' ); ?>" class="gloriousui-btn">Download Now</a>
               </li>

         <?php
         }
      }

   }
}
?>