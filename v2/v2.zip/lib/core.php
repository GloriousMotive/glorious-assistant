<?php
/**
 * fetch all files from a directory
 */

$glorious_motive_files  = array(
   'lib/theme-menu.php',
);

foreach ( $glorious_motive_files as $glorious_motive_file ) {
   require GLORIOUS_MOTIVE_PLUGIN_DIR . $glorious_motive_file;   
}

$active_plugins = apply_filters( 'active_plugins', get_option( 'active_plugins' ) );
if (! in_array( 'advanced-custom-fields-pro/acf.php', $active_plugins ) ) {
    function get_field(){
       
    }
}


function ocdi_plugin_page_setup( $default_settings ) {
   $default_settings['parent_slug'] = 'themes.php';
   $default_settings['page_title']  = esc_html__( 'Glorious Demo Import' , 'one-click-demo-import' );
   $default_settings['menu_title']  = esc_html__( 'Import Theme Demos' , 'one-click-demo-import' );
   $default_settings['capability']  = 'import';
   $default_settings['menu_slug']   = 'glorious-demo-import';

   return $default_settings;
}
add_filter( 'ocdi/plugin_page_setup', 'ocdi_plugin_page_setup' );



// Add plugin settings page link.
function glorious_add_settings_link($links) {
   $settings_link = '<a href="themes.php?page=glorious-demo-import">Import Demo</a> | <a href="wp-admin/admin.php?page=glorious">Settings</a>';
   array_push($links, $settings_link);
   return $links;
}
add_filter("plugin_action_links_".GLORIOUS_MOTIVE_PLUGIN_BASENAME, 'glorious_add_settings_link');

//Remove author links from plugins description




//Add links in PLugin description
function glorious_plugin_links($links, $file) {
   $plugin_file = GLORIOUS_MOTIVE_PLUGIN_BASENAME;
   if ( $file == $plugin_file ) {
      $links[] = '<a href="https://docs.gloriousmotive.com/">' . __( 'Docs & FAQs' ) . '</a>';
      $links[] = '<a href="https://support.gloriousmotive.com/">' . __( 'Support' ) . '</a>';
   }
   return $links;
}
add_filter('plugin_row_meta', 'glorious_plugin_links', 10, 2);




//Sample plugin stuff 
function licensebox_test_plugin_core($content_data){ 
	global $lb_verify_res;
	if($lb_verify_res['status']){
		$content_data .= '';
	}else{
		$content_data .= '<footer><b>You have not activated the GloriousMotive yet or your License is invalid, Please enter a valid license in the plugin options page.</b></footer>';
	}
	return $content_data;
}
add_filter('the_content', 'licensebox_test_plugin_core');