<?php
//Our Motive is Glorious