<?php
/**
 * Activate theme from GloriousThemes.com
 * 
 * @since 1.0
 * Uses Easy Digital Downloads Software Licensor
 * 
 * Depraicated
 * Now all themeforest themes are using API to verify the theme from envato directly using purchase code.
 */
if (GLORIOUS_IS_ENVATO != true) {
   //require GLORIOUS_MOTIVE_PLUGIN_DIR . 'lib/api/updater/edd_software_licensor.php';
   //glorious_edd_software_licensor_license_page_callback();
}
function glorious_edd_software_licensor_license_page_callback() {
}
?>
      
        