<?php if(!defined('ABSPATH')){ exit; } ?>
<?php $is_glorious_menu_glicense_active = " router-link-exact-active router-link-active"; ?>
<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gheader.php'; ?>

<div class="gloriousui-frame">
   <div class="gloriousui-tab"><span class="gloriousui_main_title">Activate your <?php echo GLORIOUS_THEME_NAME;?> Theme</span>
      <p>
         To get Updates, Bug fixes and Support for <?php echo GLORIOUS_THEME_NAME;?> Theme! Activate your theme today. Enter the Purchase Code of <?php echo GLORIOUS_THEME_NAME;?>
         from ThemeForest and your Name, then Click on Activate.
      </p>
<?php
if (GLORIOUS_IS_ENVATO != false) {
      licensebox_test_plugin_page();
} else {
	require GLORIOUS_MOTIVE_PLUGIN_DIR . 'lib/api/updater/edd_software_licensor.php';
	glorious_edd_software_licensor_license_page_callback();
}

function licensebox_test_plugin_page(){
	global $lbapi;
	global $lb_verify_res;
	$lb_activate_res = null;
	$lb_deactivate_res = null;
	if(!empty($_POST['client_name'])&&!empty($_POST['license_code'])){
		check_admin_referer('lb_update_license', 'lb_update_license_sec');
		$lb_activate_res = $lbapi->activate_license(
			strip_tags(trim($_POST['license_code'])), 
			strip_tags(trim($_POST['client_name']))
		);
		$lb_verify_res = $lbapi->verify_license();
	}
	if(!empty($_POST['lb_deactivate'])){
		check_admin_referer('lb_deactivate_license', 'lb_deactivate_license_sec');
		$lb_deactivate_res = $lbapi->deactivate_license();
		$lb_verify_res = $lbapi->verify_license();
	}
	$lb_update_data = $lbapi->check_update(); ?>

	<div class="wrap">

		<?php if($lb_verify_res['status']){ ?> 
			<div class="panel-notice notice-info">
				<p style="padding:0;margin:0;">Activated! Your license is valid.</p>
			</div> 
		<?php }else{ ?> 
			<div class="panel-notice notice-error">
				<p style="padding:0;margin:0;"><?php echo (!empty($lb_activate_res['message']))?$lb_activate_res['message']:'No license has been provided yet or the provided license is invalid.' ?></p>
			</div> 
		<?php }?>



		<form action="" method="post">
			<?php wp_nonce_field('lb_update_license', 'lb_update_license_sec'); ?>
         <?php if(! $lb_verify_res['status']){ ?>
            <div class="gloriousui-core-setting" id="set-199">
               <span class="gloriousui_text">
                  <span class="gloriousui_h2">Enable The Update & Support</span> 
                  <span class="gloriousui_p">Enter your Purchase Code & email id to enable Support and Theme Update.<br> Your purchase code is in the Downloads folder in Themeforest.<br><br> Login to Themeforest > Downloads > <?php echo GLORIOUS_THEME_NAME;?> > License Certificate & Purchase Code</span>
               </span> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> 
               <span class="gloriousui_set">
                  <div class="gloriousui-color-picker gloriousui-popup-holder gloriousui_m" value="Primary">
                     <input type="text" name="license_code" class="gloriousui_s" style="width: auto;"  placeholder="<?php
                     if ($lb_verify_res['status']) {
                         echo 'Activated - Enter the license code here to update';
                     } else {
                         echo 'XXXX-XXXX-XXXXX';
                     } ?>" required>
                  </div> 
                  <small class="gloriousui-colors-label">Enter Purchase Code</small> 
                  <span class="gloriousui_set gloriousui_l" style="display: flex;">
                     <input type="text" name="client_name" class="gloriousui_s" style="width: auto;" placeholder="<?php
                     if ($lb_verify_res['status']) {
                         echo 'Enter your name/licensee\'s name here to update';
                     } else {
                         echo 'your_email@gmail.com';
                     } ?>" required>
                      <br>
                     <input type="submit" value="Activate" style="width: 100%; margin-left: 10px; background:#532df5; color:#fff;border-radius: 4px;max-width:180px;max-height:40px;">
                  </span> 
                  <small>Your Email ID</small>
               </span> <!----> <!----> <!----> <!----> <!---->
            </div>
         <?php } else { ?>
            <div class="gloriousui-core-setting" id="set-106">
               <span class="gloriousui_text">
                  <h2 class="title">License Status</h2> 
                  <span class="gloriousui_p">Congratulations!! Your License is <b>ACTIVE NOW.</b></span>
               </span> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> 
               <span class="gloriousui_set">
                  <label data-v-33203615="" class="vue-js-switch toggled">
                     <input data-v-33203615="" type="checkbox" class="v-switch-input"> 
                     <div data-v-33203615="" class="v-switch-core" style="width: 54px; height: 24px; background-color: var(--gloriousui-primary); border-radius: 12px;">
                        <div data-v-33203615="" class="v-switch-button" style="width: 18px; height: 18px; transition: transform 300ms ease 0s; transform: translate3d(33px, 3px, 0px); background: rgb(255, 255, 255);">
                        </div>
                     </div> <!---->
                  </label>
               </span> <!----> <!----> <!---->
            </div>
         <?php } ?>
		</form>
		<?php if($lb_verify_res['status']){ ?>
			<h2 class="title" style="padding-top:10px;">Deactivate License</h2>
			<p style="max-width: 450px;">
				If you wish to use this license for activating plugin on a different server, you can first release your license from this server by deactivating it below.<br><br> If found violating the License and activating on Multiple Websites, your license will be deactivated.<br><br>Themeforest provides License for one website only.
			</p>
			<?php if(empty($lb_deactivate_res)){ ?>
				<form action="" method="post" style="padding:10px 0;">
					<?php wp_nonce_field('lb_deactivate_license', 'lb_deactivate_license_sec'); ?>
					<input type="hidden" name="lb_deactivate" value="yes">
					<input type="submit" value="Deactivate License on this Website" class="gloriousui-btn gloriousui">
				</form>
			<?php } ?>
		<?php } ?>
		<?php if($lb_verify_res['status']){ ?>
			<h2 class="title" style="padding-top:10px;">Plugin Updates</h2>
			<p>
				<strong><?php echo esc_html($lb_update_data['message']); ?></strong>
			</p>
			<?php if($lb_update_data['status']){ ?>
				<p style="max-width: 700px;">Changelog: 
					<?php echo strip_tags($lb_update_data['changelog'], '<ol><ul><li><i><b><strong><p><br><a><blockquote>'); ?>
				</p>
				<?php if(!empty($_POST['update_id'])){
					check_admin_referer('lb_update_download', 'lb_update_download_sec');
					$lbapi->download_update(
						strip_tags(trim($_POST['update_id'])), 
						strip_tags(trim($_POST['has_sql'])), 
						strip_tags(trim($_POST['version']))
					);
					if (false !== get_transient('licensebox_next_update_check')) {
						delete_transient('licensebox_next_update_check');
					}
				?>
				<?php }else{ ?>
					<form action="" method="POST">
						<?php wp_nonce_field('lb_update_download', 'lb_update_download_sec'); ?>
						<input type="hidden" value="<?php echo esc_attr($lb_update_data['update_id']); ?>" name="update_id">
						<input type="hidden" value="<?php echo esc_attr($lb_update_data['has_sql']); ?>" name="has_sql">
						<input type="hidden" value="<?php echo esc_attr($lb_update_data['version']); ?>" name="version">
						<div style="padding-top: 10px;">
							<input type="submit" value="Download and Install Update" class="button button-secondary">
						</div>
					</form>
				<?php } ?>
			<?php } ?>
		<?php } ?>
	</div>
<?php }
      ?>
      
   </div>
</div>

<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gfooter.php'; ?>            