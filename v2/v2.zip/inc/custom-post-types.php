<?php
// File Security Check
if (!defined('ABSPATH')) {
	exit;
}
class GloriousCustomPosts
{
	function __construct()
	{
		add_action( 'admin_menu', array($this, 'glorious_header_footer_menu') );
		// Header
		add_action('init', array($this, 'glorious_header'));
		add_action('init', array($this, 'glorious_footer'));
		add_action('init', array($this, 'glorious_megamenu'));

		// team 
        if (glorious_check_cpt('team')) {
            add_action('init', array($this, 'glorious_team'));
        }

		// services 
        if (glorious_check_cpt('service')) {
            add_action('init', array($this, 'glorious_service'));
            add_action('init', array($this, 'glorious_service_category'));
            add_action('init', array($this, 'glorious_service_tags'));
        }

		// Portfolios 
        if (glorious_check_cpt('portfolio')) {
            add_action('init', array($this, 'glorious_portfolio'));
            add_action('init', array($this, 'glorious_portfolio_category'));
            add_action('init', array($this, 'glorious_portfolio_tags'));
        }

		// Portfolios 
        if (glorious_check_cpt('job')) {
            add_action('init', array($this, 'glorious_job'));
            add_action('init', array($this, 'glorious_job_category'));
            add_action('init', array($this, 'glorious_job_tags'));
        }

		// Testimonial
        if (glorious_check_cpt('testimonial')) {
            add_action('init', array($this, 'glorious_testimonial'));
            // add_action('init', array($this, 'glorious_portfolio_category'));
            // add_action('init', array($this, 'glorious_portfolio_tags'));
        }

	}

	public function glorious_header_footer_menu() {
		add_menu_page(
			'Header & Footer',
			'Header & Footer',
			'read',
			'header-footer',
			'',
			'dashicons-archive',
			40
		);
	 }
	 /**
	 *
	 * Glorious Header Footer Post Type
	 *
	 */
	public function glorious_header()
	{
		$labels = array(
			'name'               => _x('Header', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Header', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Header', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Header', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Header', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Header', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Header', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Header', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Header', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Headers', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Headers', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Headers found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Headers found in Trash.', 'gloriousmotive-textdomain')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'show_in_menu' 		 => 'header-footer',
			'rewrite'            => array('slug' => 'header'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title','elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('glorious_header', $args);
	}

	public function glorious_footer()
	{
		$labels = array(
			'name'               => _x('Footer', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Footer', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Footer', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Footer', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Footer', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Footer', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Footer', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Footer', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Footer', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Footers', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Footers', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Footers found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Footers found in Trash.', 'gloriousmotive-textdomain')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'footer'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'show_in_menu' 		 => 'header-footer',
			'supports'           => array('title','elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('glorious_footer', $args);
	}


	public function glorious_megamenu()
	{
		$labels = array(
			'name'               => _x('Mega Menu', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Mega Menu', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Mega Menu', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Mega Menu', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Mega Menu', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Mega Menu', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Mega Menu', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Mega Menu', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Mega Menu', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Mega Menus', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Mega Menus', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Mega Menus found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Mega Menus found in Trash.', 'gloriousmotive-textdomain')
		);

		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'megamenu'),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			// 'show_in_menu' 		 => 'header-footer',
			'supports'           => array('title','elementor', 'thumbnail',  'page-attributes')
		);
		register_post_type('glorious_megamenu', $args);
	}

	/**
	 *
	 * glorious Service Custom Post Type
	 *
	 */
	public function glorious_service()
	{
		$labels = array(
			'name'               => _x('Service', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Service', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Service', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Service', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Service', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Service', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Service', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Service', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Service', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Services', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Services', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Services found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Services found in Trash.', 'gloriousmotive-textdomain')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-megaphone',
			'rewrite'            => array('slug' => 'service', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('elementor', 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes')
		);
		register_post_type('service', $args);
	}
	public function glorious_service_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'gloriousmotive-textdomain'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'gloriousmotive-textdomain'),
			'search_items'      => __('Search Categories', 'gloriousmotive-textdomain'),
			'all_items'         => __('All Categories', 'gloriousmotive-textdomain'),
			'parent_item'       => __('Parent Category', 'gloriousmotive-textdomain'),
			'parent_item_colon' => __('Parent Category:', 'gloriousmotive-textdomain'),
			'edit_item'         => __('Edit Category', 'gloriousmotive-textdomain'),
			'update_item'       => __('Update Category', 'gloriousmotive-textdomain'),
			'add_new_item'      => __('Add New Category', 'gloriousmotive-textdomain'),
			'new_item_name'     => __('New Category Name', 'gloriousmotive-textdomain'),
			'menu_name'         => __('Category', 'gloriousmotive-textdomain'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'service-category'),
		);
		register_taxonomy('service-category', array('service'), $args);
	}
	public function glorious_service_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'gloriousmotive-textdomain'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'gloriousmotive-textdomain'),
			'search_items'      => __('Search Tags', 'gloriousmotive-textdomain'),
			'all_items'         => __('All Tags', 'gloriousmotive-textdomain'),
			'parent_item'       => __('Parent Tag', 'gloriousmotive-textdomain'),
			'parent_item_colon' => __('Parent Tag:', 'gloriousmotive-textdomain'),
			'edit_item'         => __('Edit Tag', 'gloriousmotive-textdomain'),
			'update_item'       => __('Update Tag', 'gloriousmotive-textdomain'),
			'add_new_item'      => __('Add New Tag', 'gloriousmotive-textdomain'),
			'new_item_name'     => __('New Tag Name', 'gloriousmotive-textdomain'),
			'menu_name'         => __('Tag', 'gloriousmotive-textdomain'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'pf-tag'),
		);
		register_taxonomy('service-tag', array('service'), $args);
	}
	/**
	 *
	 * Glorious Team Post Type
	 *
	 */
	public function glorious_team()
	{
		$labels = array(
			'name'               => _x('Team Member', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Team Member', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Team Member', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Team Member', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Member', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Member', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Member', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Member', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Member', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Team Members', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Team Members', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Team Members found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Team Members found in Trash.', 'gloriousmotive-textdomain')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'team', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('team', $args);
	}

	/**
	 *
	 * Glorious Portfolio Post Type
	 *
	 */
	public function glorious_portfolio()
	{
		$labels = array(
			'name'               => _x('Portfolio', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Portfolio', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Portfolio', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Portfolio', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Portfolio', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Portfolio', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Portfolio', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Portfolio', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Portfolio', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Portfolios', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Portfolios', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Portfolios found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Portfolios found in Trash.', 'gloriousmotive-textdomain')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'portfolio', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('portfolio', $args);
	}
	public function glorious_portfolio_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'gloriousmotive-textdomain'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'gloriousmotive-textdomain'),
			'search_items'      => __('Search Categories', 'gloriousmotive-textdomain'),
			'all_items'         => __('All Categories', 'gloriousmotive-textdomain'),
			'parent_item'       => __('Parent Category', 'gloriousmotive-textdomain'),
			'parent_item_colon' => __('Parent Category:', 'gloriousmotive-textdomain'),
			'edit_item'         => __('Edit Category', 'gloriousmotive-textdomain'),
			'update_item'       => __('Update Category', 'gloriousmotive-textdomain'),
			'add_new_item'      => __('Add New Category', 'gloriousmotive-textdomain'),
			'new_item_name'     => __('New Category Name', 'gloriousmotive-textdomain'),
			'menu_name'         => __('Category', 'gloriousmotive-textdomain'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-category'),
		);
		register_taxonomy('portfolio-category', array('portfolio'), $args);
	}
	public function glorious_portfolio_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'gloriousmotive-textdomain'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'gloriousmotive-textdomain'),
			'search_items'      => __('Search Tags', 'gloriousmotive-textdomain'),
			'all_items'         => __('All Tags', 'gloriousmotive-textdomain'),
			'parent_item'       => __('Parent Tag', 'gloriousmotive-textdomain'),
			'parent_item_colon' => __('Parent Tag:', 'gloriousmotive-textdomain'),
			'edit_item'         => __('Edit Tag', 'gloriousmotive-textdomain'),
			'update_item'       => __('Update Tag', 'gloriousmotive-textdomain'),
			'add_new_item'      => __('Add New Tag', 'gloriousmotive-textdomain'),
			'new_item_name'     => __('New Tag Name', 'gloriousmotive-textdomain'),
			'menu_name'         => __('Tag', 'gloriousmotive-textdomain'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'portfolio-tag'),
		);
		register_taxonomy('portfolio-tag', array('portfolio'), $args);
	}

	/**
	 *
	 * Glorious Job Post Type
	 *
	 */
	public function glorious_job()
	{
		$labels = array(
			'name'               => _x('Job', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Job', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Job', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Job', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Job', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Job', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Job', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Job', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Job', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Jobs', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Jobs', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Jobs found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Jobs found in Trash.', 'gloriousmotive-textdomain')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-id',
			'rewrite'            => array('slug' => 'job', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'elementor', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('job', $args);
	}
	public function glorious_job_category()
	{
		$labels = array(
			'name'              => _x('Categories', 'taxonomy general name', 'gloriousmotive-textdomain'),
			'singular_name'     => _x('Category', 'taxonomy singular name', 'gloriousmotive-textdomain'),
			'search_items'      => __('Search Categories', 'gloriousmotive-textdomain'),
			'all_items'         => __('All Categories', 'gloriousmotive-textdomain'),
			'parent_item'       => __('Parent Category', 'gloriousmotive-textdomain'),
			'parent_item_colon' => __('Parent Category:', 'gloriousmotive-textdomain'),
			'edit_item'         => __('Edit Category', 'gloriousmotive-textdomain'),
			'update_item'       => __('Update Category', 'gloriousmotive-textdomain'),
			'add_new_item'      => __('Add New Category', 'gloriousmotive-textdomain'),
			'new_item_name'     => __('New Category Name', 'gloriousmotive-textdomain'),
			'menu_name'         => __('Category', 'gloriousmotive-textdomain'),
		);
		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-category'),
		);
		register_taxonomy('job-category', array('job'), $args);
	}
	public function glorious_job_tags()
	{
		$labels = array(
			'name'              => _x('Tags', 'taxonomy general name', 'gloriousmotive-textdomain'),
			'singular_name'     => _x('Tag', 'taxonomy singular name', 'gloriousmotive-textdomain'),
			'search_items'      => __('Search Tags', 'gloriousmotive-textdomain'),
			'all_items'         => __('All Tags', 'gloriousmotive-textdomain'),
			'parent_item'       => __('Parent Tag', 'gloriousmotive-textdomain'),
			'parent_item_colon' => __('Parent Tag:', 'gloriousmotive-textdomain'),
			'edit_item'         => __('Edit Tag', 'gloriousmotive-textdomain'),
			'update_item'       => __('Update Tag', 'gloriousmotive-textdomain'),
			'add_new_item'      => __('Add New Tag', 'gloriousmotive-textdomain'),
			'new_item_name'     => __('New Tag Name', 'gloriousmotive-textdomain'),
			'menu_name'         => __('Tag', 'gloriousmotive-textdomain'),
		);
		$args = array(
			'hierarchical'      => false,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'job-tag'),
		);
		register_taxonomy('job-tag', array('job'), $args);
	}
	
	//Testimonial
	public function glorious_testimonial()
	{
		$labels = array(
			'name'               => _x('Testimonial', 'post type general name', 'gloriousmotive-textdomain'),
			'singular_name'      => _x('Testimonial', 'post type singular name', 'gloriousmotive-textdomain'),
			'menu_name'          => _x('Testimonial', 'admin menu', 'gloriousmotive-textdomain'),
			'name_admin_bar'     => _x('Testimonial', 'add new on admin bar', 'gloriousmotive-textdomain'),
			'add_new'            => __('Add New Testimonial', 'gloriousmotive-textdomain'),
			'add_new_item'       => __('Add New Testimonial', 'gloriousmotive-textdomain'),
			'new_item'           => __('New Testimonial', 'gloriousmotive-textdomain'),
			'edit_item'          => __('Edit Testimonial', 'gloriousmotive-textdomain'),
			'view_item'          => __('View Testimonial', 'gloriousmotive-textdomain'),
			'all_items'          => __('All Testimonial', 'gloriousmotive-textdomain'),
			'search_items'       => __('Search Testimonial', 'gloriousmotive-textdomain'),
			'parent_item_colon'  => __('Parent :', 'gloriousmotive-textdomain'),
			'not_found'          => __('No Testimonial found.', 'gloriousmotive-textdomain'),
			'not_found_in_trash' => __('No Testimonial found in Trash.', 'gloriousmotive-textdomain')
		);
		$args = array(
			'labels'             => $labels,
			'description'        => __('Description.', 'gloriousmotive-textdomain'),
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'menu_icon'          => 'dashicons-testimonial',
			'rewrite'            => array('slug' => 'glorious_testimonial', 'with_front' => true, 'pages' => true, 'feeds' => true),
			'capability_type'    => 'post',
			'has_archive'        => false,
			'hierarchical'       => true,
			'menu_position'      => null,
			'supports'           => array('title', 'editor', 'thumbnail',  'page-attributes')
		);
		register_post_type('glorious_testimonial', $args);
	}
	public function glorious_testimonial_category()
		{
			$labels = array(
				'name'              => _x('Categories', 'taxonomy general name', 'gloriousmotive-textdomain'),
				'singular_name'     => _x('Category', 'taxonomy singular name', 'gloriousmotive-textdomain'),
				'search_items'      => __('Search Categories', 'gloriousmotive-textdomain'),
				'all_items'         => __('All Categories', 'gloriousmotive-textdomain'),
				'parent_item'       => __('Parent Category', 'gloriousmotive-textdomain'),
				'parent_item_colon' => __('Parent Category:', 'gloriousmotive-textdomain'),
				'edit_item'         => __('Edit Category', 'gloriousmotive-textdomain'),
				'update_item'       => __('Update Category', 'gloriousmotive-textdomain'),
				'add_new_item'      => __('Add New Category', 'gloriousmotive-textdomain'),
				'new_item_name'     => __('New Category Name', 'gloriousmotive-textdomain'),
				'menu_name'         => __('Category', 'gloriousmotive-textdomain'),
			);
			$args = array(
				'hierarchical'      => true,
				'labels'            => $labels,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => array('slug' => 'portfolio-category'),
			);
			register_taxonomy('testimonial_category', array('glorious_testimonial'), $args);
		}
		public function glorious_testimonial_tags()
		{
			$labels = array(
				'name'              => _x('Tags', 'taxonomy general name', 'gloriousmotive-textdomain'),
				'singular_name'     => _x('Tag', 'taxonomy singular name', 'gloriousmotive-textdomain'),
				'search_items'      => __('Search Tags', 'gloriousmotive-textdomain'),
				'all_items'         => __('All Tags', 'gloriousmotive-textdomain'),
				'parent_item'       => __('Parent Tag', 'gloriousmotive-textdomain'),
				'parent_item_colon' => __('Parent Tag:', 'gloriousmotive-textdomain'),
				'edit_item'         => __('Edit Tag', 'gloriousmotive-textdomain'),
				'update_item'       => __('Update Tag', 'gloriousmotive-textdomain'),
				'add_new_item'      => __('Add New Tag', 'gloriousmotive-textdomain'),
				'new_item_name'     => __('New Tag Name', 'gloriousmotive-textdomain'),
				'menu_name'         => __('Tag', 'gloriousmotive-textdomain'),
			);
			$args = array(
				'hierarchical'      => false,
				'labels'            => $labels,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'rewrite'           => array('slug' => 'portfolio-tag'),
			);
			register_taxonomy('testimonial_tag', array('glorious_testimonial'), $args);
		}
}
$gloriousCcases_stydyInstance = new GloriousCustomPosts;
