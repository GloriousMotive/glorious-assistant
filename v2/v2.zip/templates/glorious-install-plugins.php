<?php $is_glorious_menu_gpinstall_active = " router-link-exact-active router-link-active"; ?>
<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gheader.php'; ?>

<div class="gloriousui-frame">
   <div class="gloriousui-tab">
      <span class="gloriousui_h1">Install Essential Plugins required for <?php echo GLORIOUS_THEME_NAME;?> Theme</span>
      <p>
         Install and Activate all the plugins for the Theme to Work perfectly.
      </p>
      <style>
         table.widefat,.widefat td, .widefat th {
            background: #262b3b !important;
            border: none !important;
            color: #fff !important;
         }  
         .gloriousui-tab {
            max-width:100% !important;
         }
         div#setting-error-tgmpa {
            display: none !important;
         }
         .subsubsub>li>a, .subsubsub>li>a .count {
            color: #fff !important;
         }
         .tablenav.top {
            padding: 20px 0;
         }
         table.wp-list-table.widefat.fixed {
            margin: 35px 0;
         }
         .widefat td, .widefat th {
            padding: 10px 18px !important;
         }
         th.check-column, td#cb, td.column-cb {
            padding: 15px 0 0 10px !important;
         }

      </style>
      <?php 
      $config['has_notices'] = false;
      do_action( 'gloriousmotive_theme_setup_plugins' );?>
   </div>
</div>

<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gfooter.php'; ?>            