<?php $is_glorious_menu_dash_active = " router-link-exact-active router-link-active"; ?>
<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gheader.php'; ?>

               <div class="gloriousui-frame">
                  <div class="gloriousui-tab"><span class="gloriousui_main_title">Welcome to <?php echo GLORIOUS_THEME_NAME;?> Theme</span>
                     <p>
                        Thank you for installing <?php echo GLORIOUS_THEME_NAME;?> Theme! Everything in <?php echo GLORIOUS_THEME_NAME;?> is
                        streamlined to make your website building experience as simple and intuitive as possible. We
                        hope you'll
                        turn it into a powerful marketing asset that brings customers to your digital doorstep.
                     </p>
                     <div class="gloriousui-box-shadow gloriousui-dashboard-updates"
                        style="background-image: url(&quot;<?php echo GLORIOUS_MOTIVE_PLUGIN_URL . '/assets/img/demo-import-bg.jpg'; ?>&quot;);">
                        <span class="gloriousui_h1">Activate <?php echo GLORIOUS_THEME_NAME;?> to enable automatic updates!</span>
                        <p>To receive automatic updates of your theme, you need to activate your license key.</p> <a
                           class="gloriousui-btn gloriousui-btn-auto gloriousui-white">Activate Now</a>
                     </div>
                     <div class="gloriousui-row">
                        <div class="gloriousui-box-shadow gloriousui-knoledge">
                           <div class="gloriousui-ico"
                              style="background-image: url(&quot;<?php echo GLORIOUS_MOTIVE_PLUGIN_URL . '/assets/img/icon-knowledgebase.svg'; ?>&quot;);">
                           </div> <span class="gloriousui_h1">Knowledgebase</span>
                           <p>Cut your learning curve and get started with Motive in no time! Read our well-structured
                              docs.</p> <a
                              href="https://docs.gloriousmotive.com/help-center/categories/4/getting-started?utm_source=ThemeOptions&amp;utm_medium=Dashboard"
                              target="_blank" class="gloriousui-btn gloriousui-btn-auto">Start Reading</a>
                        </div>
                        <div class="gloriousui-box-shadow gloriousui-help">
                           <div class="gloriousui-ico"
                              style="background-image: url(&quot;<?php echo GLORIOUS_MOTIVE_PLUGIN_URL . '/assets/img/icon-help.svg'; ?>&quot;);">
                           </div> <span class="gloriousui_h1">Need Help?</span>
                           <p>We've got your back. Looking forward to helping you design a website you can be proud of.
                           </p> <a
                              href="https://support.gloriousmotive.com/help-center?utm_source=ThemeOptions&amp;utm_medium=Dashboard"
                              target="_blank" class="gloriousui-btn gloriousui-btn-auto">Get Support</a>
                        </div>
                        <div class="gloriousui-box-shadow gloriousui-feature">
                           <div class="gloriousui-ico"
                              style="background-image: url(&quot;<?php echo GLORIOUS_MOTIVE_PLUGIN_URL . '/assets/img/icon-suggest-feature.svg'; ?>&quot;);">
                           </div> <span class="gloriousui_h1">Suggest a Feature</span>
                           <p>We're always working to improve Motive, so we'd love to hear how we can do better.</p> <a
                              href="https://gloriousmotive.com/feedback" target="_blank" class="gloriousui-btn gloriousui-btn-auto">Send
                              Feedback</a>
                        </div>
                     </div>
                  </div>
               </div>

<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gfooter.php'; ?>            