</div>
            <footer>
               <!---->
            </footer>
         </div>
      </div>
      <!---->
      <div class="v-tour">
         <!---->
      </div>
   </div>
</div>