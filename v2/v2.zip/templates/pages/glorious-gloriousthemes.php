<?php $is_glorious_menu_gthemes_active = " router-link-exact-active router-link-active"; ?>
<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gheader.php'; ?>
<?php
// 
/**
 * This will be filled with real data on our next upload @version 1.0.1
 * For now, we will use the same data as the one on.
 * 
 * To be Updated, once approved by the WordPress Team
 */
?>
<div class="gloriousui-frame">
   <div data-v-0577a48d="" class="gloriousui-tab"><span data-v-0577a48d="" class="gloriousui_h1">GloriousThemes Products</span>
      <p data-v-0577a48d="">Themes that would make your website Glorious.</p>
      <div data-v-0577a48d="" class="gloriousui-small-separator">Our All Products</div>
      <ul data-v-0577a48d="" class="gloriousui-plugins-list">
         <?php 
         require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'lib/fetch/fetch-glorious-themes.php';
         glorious_themes();
         ?>
      </ul>
   </div>
</div>

<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gfooter.php'; ?>            