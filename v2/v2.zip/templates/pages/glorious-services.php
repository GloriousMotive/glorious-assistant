<?php $is_glorious_menu_gservices_active = " router-link-exact-active router-link-active"; ?>
<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gheader.php'; ?>
<?php
// 
/**
 * This will be filled with real data on our next upload @version 1.0.1
 * For now, we will use the same data as the one on.
 * 
 * To be Updated, once approved by the WordPress Team
 */
?>
<div class="gloriousui-frame">
   <div data-v-0577a48d="" class="gloriousui-tab"><span data-v-0577a48d="" class="gloriousui_h1">Glorious Services</span>
      <p data-v-0577a48d="">Need Help with your Website.</p>
      <div data-v-0577a48d="" class="gloriousui-small-separator">Glorious Services are here for you</div>
      <ul data-v-0577a48d="" class="gloriousui-plugins-list">
         <?php 
         require_once GLORIOUS_MOTIVE_PLUGIN_DIR . 'lib/fetch/fetch-glorious-services.php';
         glorious_services();
         ?>
      </ul>
   </div>
</div>

<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gfooter.php'; ?>            