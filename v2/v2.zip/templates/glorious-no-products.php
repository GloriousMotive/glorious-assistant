<?php $is_glorious_menu_dash_active = " router-link-exact-active router-link-active"; ?>
<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gheader.php'; ?>

               <div class="gloriousui-frame">
                  <div class="gloriousui-tab"><span class="gloriousui_main_title">Welcome to <?php echo GLORIOUS_THEME_NAME;?> Theme</span>
                     <p>
                        Thank you for installing <?php echo GLORIOUS_THEME_NAME;?> Theme! Everything in <?php echo GLORIOUS_THEME_NAME;?> is
                        streamlined to make your website building experience as simple and intuitive as possible. We
                        hope you'll
                        turn it into a powerful marketing asset that brings customers to your digital doorstep.
                     </p>
                     <?php
                     /**
                      * If no Products are active for Glorious Motive Plugin
                     */

                     echo '<div class="wrap">';
                     echo '<h1>Glorious Motive</h1>';
                     echo '<div class="error">';
                     echo '<p>';
                     echo '<strong>';
                     echo 'No Products are active for Glorious Motive Plugin. Please activate at least one product.';
                     echo '</strong>';
                     echo '</p>';
                     echo '</div>';
                     echo '</div>';
                     ?>
                  </div>
               </div>

<?php include GLORIOUS_MOTIVE_PLUGIN_DIR . 'templates/gfooter.php'; ?>            