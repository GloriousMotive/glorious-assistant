<?php
/**
 * Plugin Name: GloriousMotive
 * Plugin URI: http://www.gloriousmotive.com
 * Description: GloriousMotive is a core plugin for themes created by GloriousMotive and GloriousThemes to add functionality and specialities.
 * Version: 1.0.0
 * Author: GloriousThemes
 * Author URI: http://www.gloriousThemes.com
 * Tested up to: 5.4
 * Requires PHP: 5.6
 * License: GPL2
 * Text Domain: gloriousmotive
 * Domain Path: /languages/
 * 
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 *
 * @package     Glorious Motive
 * @author      GloriousMotive
 * @copyright   2021 GloriousMotive 
 * @license     GPL-2.0+
 *
 * @wordpress-plugin
 */

if ( ! defined( 'ABSPATH' ) ) {
   exit; // Exit if accessed directly
}

define ( 'GLORIOUS_MOTIVE_VERSION', '1.0' );
define ( 'GLORIOUS_MOTIVE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define ( 'GLORIOUS_MOTIVE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define ( 'GLORIOUS_MOTIVE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

$theme_version = wp_get_theme();
define ( 'GLORIOUS_THEME_VERSION', $theme_version->get( 'Version' ) );
define ( 'GLORIOUS_THEME_NAME', $theme_version->get( 'Name' ) );

/**
 * Check if theme is active or not
 * @return boolean
 * @since 1.0
 * @version 1.0
 * 
 */
function is_glorious_theme_active() {
    $theme = wp_get_theme();
    $glorious_theme_list = array('motive','ayush','baishali','nihal','dookan','blogin');
    if (in_array( $theme->get( 'Name' ), $glorious_theme_list ) || in_array( $theme->get( 'parent_theme' ), $glorious_theme_list )) {
        return true;
    } else {
        return false;
    }
}




/**
 * Main gloriousmotive-textdomain Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class gloriousmotive_core
{

    /**
     * Plugin Version
     *
     * @since 1.0.0
     *
     * @var string The plugin version.
     */
    const VERSION = '1.0.0';

    /**
     * Minimum Elementor Version
     *
     * @since 1.0.0
     *
     * @var string Minimum Elementor version required to run the plugin.
     */
    const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

    /**
     * Minimum PHP Version
     *
     * @since 1.0.0
     *
     * @var string Minimum PHP version required to run the plugin.
     */
    const MINIMUM_PHP_VERSION = '5.6';

    /**
     * Instance
     *
     * @since 1.0.0
     *
     * @access private
     * @static
     *
     * @var gloriousmotive_core The single instance of the class.
     */
    private static $_instance = null;

    /**
     * Instance
     *
     * Ensures only one instance of the class is loaded or can be loaded.
     *
     * @since 1.0.0
     *
     * @access public
     * @static
     *
     * @return gloriousmotive_core An instance of the class.
     */
    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function __construct()
    {
        //add_action('init', [$this, 'i18n']);
        add_action('plugins_loaded', [$this, 'init']);
    }

    /**
     * Load Textdomain
     *
     * Load plugin localization files.
     *
     * Fired by `init` action hook.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function i18n()
    {
        load_plugin_textdomain('gloriousmotive-textdomain');
    }

    /**
     * Initialize the plugin
     *
     * Load the plugin only after Elementor (and other plugins) are loaded.
     * Checks for basic plugin requirements, if one check fail don't continue,
     * if all check have passed load the files required to run the plugin.
     *
     * Fired by `plugins_loaded` action hook.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function init()
    {

		
		// $this->update_checker();

        // Require the main plugin file
        require(__DIR__ . '/inc/helper-functions.php');
        require_once(__DIR__ . '/inc/custom-post-types.php');
        require_once(__DIR__ . '/inc/shortcodes.php');
        //require(__DIR__ . '/inc/elmentor-extender.php');
        require(__DIR__ . '/inc/Glorious_Nav_Walker.php');
        require(__DIR__ . '/inc/admin-column.php');


        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded')) {
            //add_action('admin_notices', [$this, 'admin_notice_missing_main_plugin']);
            return;
        }

        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
            //add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Check for required PHP version
        if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
            //add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
            return;
        }

    }


    /**
     * Admin notice
     *
     * Warning when the site doesn't have Elementor installed or activated.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function admin_notice_missing_main_plugin()
    {
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
        }

        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor */
            esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'gloriousmotive-textdomain'),
            '<strong>' . esc_html__('gloriousmotive-textdomain', 'gloriousmotive-textdomain') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'gloriousmotive-textdomain') . '</strong>'
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    /**
     * Admin notice
     *
     * Warning when the site doesn't have a minimum required Elementor version.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function admin_notice_minimum_elementor_version()
    {
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
        }

        $message = sprintf(
            /* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'gloriousmotive-textdomain'),
            '<strong>' . esc_html__('Glorious Helper', 'gloriousmotive-textdomain') . '</strong>',
            '<strong>' . esc_html__('Elementor', 'gloriousmotive-textdomain') . '</strong>',
            self::MINIMUM_ELEMENTOR_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    /**
     * Admin notice
     *
     * Warning when the site doesn't have a minimum required PHP version.
     *
     * @since 1.0.0
     *
     * @access public
     */
    public function admin_notice_minimum_php_version()
    {
        if (isset($_GET['activate'])) {
            unset($_GET['activate']);
        }

        $message = sprintf(
            /* translators: 1: Plugin name 2: PHP 3: Required PHP version */
            esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'gloriousmotive-textdomain'),
            '<strong>' . esc_html__('gloriousmotive-textdomain', 'gloriousmotive-textdomain') . '</strong>',
            '<strong>' . esc_html__('PHP', 'gloriousmotive-textdomain') . '</strong>',
            self::MINIMUM_PHP_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

}

gloriousmotive_core::instance();






/**
 * If the Theme is not active, then create a notice in the GloriousMotive Admin
 */
if ( is_glorious_theme_active() == false ) {
   class GloriousMotiveAbsent {

      function __construct() {
         add_action( 'admin_menu', array( $this, 'gloriousmotive_admin_menu' ) );
         add_action('admin_enqueue_scripts', array( $this, 'glorious_register_styles' ));
         add_action( 'admin_notices', array( $this, 'gloriousmotive_admin_notice' ) );
      }

      function gloriousmotive_admin_menu() {
         add_menu_page( 
            'GloriousMotive', 
            'GloriousMotive', 
            'edit_theme_options', 
            'glorious', 
            array($this, 'gloriousabsent_dashboard_page'),
            'dashicons-warning', 
            '0' 
         );
      }

      function gloriousabsent_dashboard_page() {?>
         <div class="wrap">
            <h1>GloriousMotive - Theme settings</h1>
            <div class="notice notice-error">
               <h2 class="error">
                  <?php _e( 'Please activate any theme from the given list ↓', 'gloriousmotive-textdomain' ); ?>
               </h2>
               <ul>
                  <?php $glorious_theme_list = array('motive','ayush','baishali','nihal','dookan','blogin');
                  foreach( $glorious_theme_list as $theme ) { ?>
                     <li>
                        <a href="<?php echo esc_url( self_admin_url( 'themes.php' ) ); ?>">
                        <?php echo esc_html__( $theme , 'gloriousmotive' ); ?></a>
                     </li>
                  <?php } ?>
                  
               </ul>
               <p>
                  <?php _e( 'GloriousMotive is a core plugin for all the themes created by GloriousThemes.com & GloriousMotive.com. Please activate any theme by GloriousThemes to use GloriousMotive plugin.', 'gloriousmotive-textdomain' ); ?>
               </p>
               <a href="<?php echo esc_url( self_admin_url( 'themes.php' ) ); ?>">
                  <?php _e( '→ Click here to Activate your choice of theme', 'gloriousmotive-textdomain' ); ?>
               </a>
               <p>
                  <?php _e( 'If you are not using any Themes from GloriousThemes, then you can download free themes from GloriousThemes.com website and install it on your site.', 'gloriousmotive-textdomain' ); ?>
               </p>
               <a href="<?php echo esc_url( 'https://gloriousthemes.com/?utm_source=gloriousmotive_plugin_nonactive' ); ?>">
                  <strong><?php _e( '→ Click here to know more about GloriousThemes', 'gloriousmotive-textdomain' ); ?></strong>
               </a><br><br><br>
            </div>
          </div>
      <?php
      }

      //display admin notices
      function gloriousmotive_admin_notice() {
         $class = 'notice notice-error';
         $message = __( 'GloriousMotive Plugin requires a Theme by GloriousThemes to be active. Download Free Themes, on Gloriousthemes.com', 'gloriousmotive-textdomain' );
      
         printf( '<div class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), esc_html( $message ) );
      }



      //Register Admin Styles
      function glorious_register_styles()
      {
          wp_enqueue_style('gloriousmotive-main-plugin-css', GLORIOUS_MOTIVE_PLUGIN_URL . 'assets/css/gloriousmotive.css', array(), GLORIOUS_MOTIVE_VERSION);
          wp_enqueue_style('gloriousmotive-support-status-css', GLORIOUS_MOTIVE_PLUGIN_URL . 'assets/css/copy-for-support.css', array(), GLORIOUS_MOTIVE_VERSION);
          //wp_register_style( 'gloriousmotive-main-plugin-css' );
      }

   }
   $glorious_motive_absent = new GloriousMotiveAbsent();

} else {

   /** Run if the themes by GLoriousThemes/GloriousMotive are active */
    if (! class_exists('GloriousMotive')) {
        class GloriousMotive
        {
            public function __construct()
            {
                add_action('plugins_loaded', array( $this, 'glorious_load_textdomain' ));
                add_action('after_setup_theme', array( $this, 'glorious_load_core' ));
                add_action('admin_enqueue_scripts', array( $this, 'glorious_register_styles' ));
                add_action( 'admin_enqueue_scripts', array( $this, 'glorious_admin_scripts') );
                add_action('init', array($this, 'gloriousdashboard_init' ));
            }

            public function glorious_load_textdomain()
            {
                load_plugin_textdomain('gloriousmotive-textdomain', false, dirname(plugin_basename(__FILE__)) . '/languages/');
            }

            public function glorious_load_core()
            {
                require_once('lib/core.php');
            }

            //Execute after plugins are loaded
            public function gloriousdashboard_init()
            {
                //current user can manage options
                if (current_user_can('manage_options')) {
                    add_action('admin_menu', 'gloriousdash_dashboard_register_additional_menu');
                }
            }
         

            //Register Admin Styles
            public function glorious_register_styles()
            {
                wp_enqueue_style('gloriousmotive-main-plugin-css', GLORIOUS_MOTIVE_PLUGIN_URL . 'assets/css/gloriousmotive.css', array(), GLORIOUS_MOTIVE_VERSION);
                wp_enqueue_style('gloriousmotive-support-status-css', GLORIOUS_MOTIVE_PLUGIN_URL . 'assets/css/copy-for-support.css', array(), GLORIOUS_MOTIVE_VERSION);
                //wp_register_style( 'gloriousmotive-main-plugin-css' );
            }

            //Register Admin Scripts
            public function glorious_admin_scripts()
            {
                wp_enqueue_script('gloriousmotive-system-status', GLORIOUS_MOTIVE_PLUGIN_URL . 'assets/js/status.js', array( 'jquery' ), GLORIOUS_MOTIVE_VERSION);
            }
        }
    }
    $gloriousmotive = new GloriousMotive();
}

/** 
 * Debugging Appsero, to be released in the future versions
if ( ! function_exists( 'glo_fs' ) ) {
   // Create a helper function for easy SDK access.
   function glo_fs() {
       global $glo_fs;

       if ( ! isset( $glo_fs ) ) {
           // Include Freemius SDK.
           require_once dirname(__FILE__) . '/lib/freemius/start.php';

           $glo_fs = fs_dynamic_init( array(
               'id'                  => '9679',
               'slug'                => 'gloriousmotive',
               'type'                => 'plugin',
               'public_key'          => 'pk_c9064c3ea66c37e0ccf213ed68b30',
               'is_premium'          => false,
               'has_addons'          => false,
               'has_paid_plans'      => false,
               'menu'                => array(
                   'slug'           => 'glorious',
                   'account'        => false,
                   'contact'        => false,
                   'support'        => false,
               ),
           ) );
       }

       return $glo_fs;
   }

   // Init Freemius.
   glo_fs();
   // Signal that SDK was initiated.
   do_action( 'glo_fs_loaded' );
}
*/

//Integrating Appsero for debugging purposes
require __DIR__ . '/lib/appsero/vendor/autoload.php';
/**
 * Initialize the plugin tracker
 *
 * Tracks only if the user has given permission, else
 * @return void
 */
function appsero_init_tracker_gloriousmotive() {

   if ( ! class_exists( 'Appsero\Client' ) ) {
     require_once __DIR__ . '/appsero/src/Client.php';
   }

   $client = new Appsero\Client( '9f66a080-bdf3-4306-9aa5-fd8e13d3dd63', 'GloriousMotive', __FILE__ );

   // Active insights
   $client->insights()->init();

   // Active automatic updater
   $client->updater();

}
appsero_init_tracker_gloriousmotive();
//ended appsero - tammatar edition

?>